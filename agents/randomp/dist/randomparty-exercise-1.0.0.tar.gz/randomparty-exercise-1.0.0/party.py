from ponpokoagent.ponpoko import PonPokoParty

def party():
    """Returns the party representing the negotiation agent."""
    return PonPokoParty
